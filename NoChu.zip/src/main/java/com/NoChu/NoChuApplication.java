package com.NoChu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NoChuApplication {

	public static void main(String[] args) {
		SpringApplication.run(NoChuApplication.class, args);
	}

}
