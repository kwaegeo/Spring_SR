package com.NoChu.dto;

public class ApiResponseDto<T> {
}
