package com.NoChu.model;

public class Board {
}
